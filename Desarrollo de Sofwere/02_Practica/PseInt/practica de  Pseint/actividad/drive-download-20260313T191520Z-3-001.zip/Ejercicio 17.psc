Algoritmo Ano_bisiesto
		Definir ano Como Entero;
		Escribir "Ingresa un a�o para conocer si es o no bisiesto:";
		Leer ano;
		Si a�o MOD 4 = 0 Y (ano MOD 100 <> 0 O ano MOD 400 = 0) Entonces
			Escribir "El a�o ", ano, " es bisiesto.";
		SiNo
			Escribir "El a�o ", ano, " no es bisiesto.";
		FinSi
FinAlgoritmo
	
